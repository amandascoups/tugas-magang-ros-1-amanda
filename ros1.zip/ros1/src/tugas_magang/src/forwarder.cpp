#include <ros/ros.h>
#include <tugas_magang/CustomMessage.h>

ros::Publisher pub;

void callback(const tugas_magang::CustomMessage::ConstPtr& msg) {
    // Forward the message
    pub.publish(*msg);
    ROS_INFO("Forwarded message: %s, sender: %s", msg->text.c_str(), msg->sender.c_str());
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "forwarder_node");
    ros::NodeHandle n;

    pub = n.advertise<tugas_magang::CustomMessage>("topic_out", 1000);
    ros::Subscriber sub = n.subscribe("topic_in", 1000, callback);

    ros::spin();

    return 0;
}

