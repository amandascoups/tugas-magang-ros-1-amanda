#include <ros/ros.h>
#include <tugas_magang/CustomMessage.h>

void callback(const tugas_magang::CustomMessage::ConstPtr& msg) {
    ROS_INFO("Received from chat/topic_in: %s, sender: %s", msg->text.c_str(), msg->sender.c_str());
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "subscriber_node");
    ros::NodeHandle n;

    ros::Subscriber sub = n.subscribe("topic_in", 1000, callback);

    ros::spin();

    return 0;
}
