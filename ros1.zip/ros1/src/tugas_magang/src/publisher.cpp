#include <ros/ros.h>
#include <tugas_magang/CustomMessage.h>

int main(int argc, char **argv) {
    ros::init(argc, argv, "publisher_node");
    ros::NodeHandle n;

    ros::Publisher pub = n.advertise<tugas_magang::CustomMessage>("topic_in", 1000);

    ros::Rate loop_rate(10);

    while (ros::ok()) {
        tugas_magang::CustomMessage msg;
        msg.text = "Hello from Publisher!";
        msg.sender = "Publisher";

        ROS_INFO("Publishing: %s, sender: %s", msg.text.c_str(), msg.sender.c_str());
        pub.publish(msg);

        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}

